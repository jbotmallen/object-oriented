/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version4;

/**
 *
 * @author Hikari Cookies
 */
public class basePlusCommissionEmployee extends commissionEmployee {
    private commissionEmployee employee;
    private double baseSalary;

    public basePlusCommissionEmployee() {
        super();
    }

    public basePlusCommissionEmployee(commissionEmployee emp, double baseSalary) {
        super(emp.empName, emp.dateHired, emp.birthDate);
        this.baseSalary = baseSalary;
        this.employee = emp;
    }

    public basePlusCommissionEmployee(commissionEmployee emp) {
        super(emp.empName, emp.dateHired, emp.birthDate, emp.totalSales);
        this.employee = emp;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }
    
    @Override
    public double computeSalary() {
        commissionEmployee emp = this.employee;
        return baseSalary + emp.computeSalary();
    }

    @Override
    public void display() {
        System.out.printf("\n%s| Base Salary : %5.0f\n| Total Salary : %5.0f\n\n"
                , this.toString(), getBaseSalary(), computeSalary());
    }
    
    @Override
    public String toString() {
        return String.format("%s\n %-40s \n%s\n%s| Total Sales : %5.0f\n", 
                "==============================================",
                "BASE PLUS COMMISSION EMPLOYEE DETAILS",
                "==============================================",
                super.getDetails(),
                this.employee.getTotalSales()
        ); 
    }
}
