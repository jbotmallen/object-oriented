/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version4;
import java.time.*;

/**
 *
 * @author Hikari Cookies
 */
public class hourlyEmployee extends Employee {
    private float totalHoursWorked;
    private float ratePerHour;
    
    public hourlyEmployee(float totalHoursWorked, float ratePerHour) {
        this.totalHoursWorked = totalHoursWorked;
        this.ratePerHour = ratePerHour;
    }

    public hourlyEmployee(Name empName, LocalDate dateHired, LocalDate birthDate) {
        super(empName, dateHired, birthDate);
    }

    public hourlyEmployee(float totalHoursWorked, float ratePerHour, Name name, LocalDate dateHired, LocalDate birthDate) {
        super(name, dateHired, birthDate);
        this.totalHoursWorked = totalHoursWorked;
        this.ratePerHour = ratePerHour;
    }

    public hourlyEmployee() {
    }

    public float getTotalHoursWorked() {
        return totalHoursWorked;
    }

    public void setTotalHoursWorked(float totalHoursWorked) {
        this.totalHoursWorked = totalHoursWorked;
    }

    public float getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(float ratePerHour) {
        this.ratePerHour = ratePerHour;
    }
    
    public double computeSalary() {
        double retval;
        float workedHours = getTotalHoursWorked();
        float rate = getRatePerHour();
        double overtime = 0;
        
        if(workedHours > 40) {
            float extraHours = workedHours - 40;
            overtime = extraHours * (rate * 1.5);
            workedHours -= extraHours;
        }
        
        retval = (workedHours * rate) + overtime;
        
        return retval;
    }
    @Override
    public void display() {
        System.out.printf("%s| Salary : %5.0f\n\n", this.toString(), computeSalary());
    }

    @Override
    public String toString() {
        return String.format("%s\n %-40s \n%s\n%s", 
                "==============================================",
                "HOURLY RATE EMPLOYEE DETAILS",
                "==============================================",
                super.toString()
        ); 
    }
}
