/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version4;
import java.time.LocalDate;

/**
 *
 * @author Hikari Cookies
 */
public class pieceWorkerEmployee extends Employee {
    private int totalPiecesFinished;
    private float ratePerPiece;

    public pieceWorkerEmployee(Name empName, LocalDate dateHired, LocalDate birthDate) {
        super(empName, dateHired, birthDate);
    }

    public pieceWorkerEmployee(Name empName, int totalPiecesFinished, float ratePerPiece, LocalDate dateHired, LocalDate birthDate) {
        super(empName, dateHired, birthDate);
        this.totalPiecesFinished = totalPiecesFinished;
        this.ratePerPiece = ratePerPiece;
    }
    
    public pieceWorkerEmployee() {
    }

    public int getTotalPiecesFinished() {
        return totalPiecesFinished;
    }

    public void setTotalPiecesFinished(int totalPiecesFinished) {
        this.totalPiecesFinished = totalPiecesFinished;
    }

    public float getRatePerPiece() {
        return ratePerPiece;
    }

    public void setRatePerPiece(float ratePerPiece) {
        this.ratePerPiece = ratePerPiece;
    }
    
    public double computeSalary() {
            double retval;
            int pieces = getTotalPiecesFinished();
            float rate = getRatePerPiece();
            float bonus = (getTotalPiecesFinished()/100) * (getRatePerPiece() * 10);
            retval = bonus + (rate * pieces);
            
            return retval;
        }
    
    @Override
    public void display() {
        System.out.printf("%20s| Salary : %05.2f\n\n", 
                 toString(), computeSalary());
        }

        @Override
        public String toString() {
            return String.format("%s\n %-40s \n%s\n%s| Rate per Piece : %5.0f\n| Total Pieces Finished : %05d\n", 
                "==============================================",
                "PIECE WORKER EMPLOYEE DETAILS",
                "==============================================",
                super.toString(), 
                getRatePerPiece(),
                getTotalPiecesFinished()
            ); 
        }
}
