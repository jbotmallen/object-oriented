/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version4;

/**
 *
 * @author Hikari Cookies
 */
public class Name {
   private String fName;
    private String mName;
    private String lName;
    private String title;
    private String suffix;

    public Name(String fName, String mName, String lName, String title) {
        this.fName = fName;
        this.mName = mName;
        this.lName = lName;
        this.title = title;
        this.suffix = " ";
    }

    public Name(String fName, String mName, String lName, String title, String suffix) {
        this.fName = fName;
        this.mName = mName;
        this.lName = lName;
        this.title = title;
        this.suffix = suffix;
    }

    public Name(String fName, String mName, String lName) {
        this.fName = fName;
        this.mName = mName;
        this.lName = lName;
        this.suffix = " ";
        this.title = " ";
    }

    public Name() {
        this("MARK ALLEN", "PILAPIL", "JUGALBOT");
        this.suffix = " ";
        this.title = " ";
    }
    
    public static Name withSuffixNoTitle(Name name, String suffix) {
         name.suffix = suffix;
         name.title = " ";
         
         return name;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }
 
    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }
    
    @Override
    public String toString() {
        return String.format("%s %s, %s %c. %s", this.title, this.fName, this.lName, this.mName.charAt(0), this.suffix);
    }

    public void displayName() {
        System.out.printf("\n\n============================================\n| %10s, %10s, %2c., %5s %5s |\n============================================\n\n",
                this.lName, this.fName, this.mName.charAt(0), this.suffix, this.title);
    }
}
