/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version4;

public class EmployeeRoster {
    private final Employee[] empList;
    private int count = 0;
    private int MAX = 10;

    public EmployeeRoster() {
        empList = new Employee[MAX];
    }

    public EmployeeRoster(int MAX) {
        this.MAX = MAX;
        this.empList = new Employee[MAX];
    }

    public int getCount() {
        return count;
    }

    public int getSize() {
        return MAX;
    }

    public void displayAllEmp() {
        int x;
        
        System.out.printf("| %5s | %30s | %10s| %15s |\n", "EMP ID", "Name", "Type", "Salary");
        for (x = 0; x < count; x++) {
            String classType = empList[x].getClass().getSimpleName();
            double salary;

            switch (empList[x]) {
                case hourlyEmployee hourlyEmployee -> salary = hourlyEmployee.computeSalary();
                case pieceWorkerEmployee pieceEmployee -> salary = pieceEmployee.computeSalary();
                case commissionEmployee commissionEmployee -> salary = commissionEmployee.computeSalary();
                default -> {
                    basePlusCommissionEmployee basePlusCommissionEmployee = (basePlusCommissionEmployee) empList[x];
                    salary = basePlusCommissionEmployee.computeSalary();
                }
            }

            System.out.printf("| %5d | %30s | %10s| PHP %15.2f | \n", 
                    empList[x].getEmpID(),
                    empList[x].getEmpName(),
                    classType,
                    salary);
        }
    }

    public void displayEmpOfType(String type) {
        Class<?> empType = switch (type.toUpperCase().charAt(0)) {
            case 'H' -> hourlyEmployee.class;
            case 'P' -> pieceWorkerEmployee.class;
            case 'C' -> commissionEmployee.class;
            case 'B' -> basePlusCommissionEmployee.class;
            default -> null;
        };

        if(empType != null) { 
            int x; 
            for (x = 0; x < count; x++) {
                if (empType.isInstance(empList[x])) {
                    empList[x].display();
                    System.out.println();
                }
            }
        }

    }

    public EmployeeRoster searchEmp(String key) {
        EmployeeRoster retRoster = new EmployeeRoster();

        int x;
        for (x = 0; x < count; x++) {
            if (empList[x].toString().contains(key)) {
                retRoster.insertEmp(empList[x]);
            }
        }
        return retRoster;
    }

    public boolean insertEmp(Employee emp) {
        boolean retval = false;
        
        if (count < MAX) {
            empList[count] = emp;
            count++;
            retval = true;
        }
        return retval;
    }

    public boolean updateEmp(int empID, Employee emp) {
        int x;
        boolean retval = false;
        
        for (x = 0; x < count && empList[x].getEmpID() != empID; x++) {}
        if (x < count) {
            empList[x] = emp;
            retval = true;
        }
        return retval;
    }

    public Employee deleteEmployee(int ID) {
        Employee temp = null;
        int x;
        for (x = 0; x < count && empList[x].getEmpID() != ID; x++) {}
        if (x < count) {
            temp = empList[x];
            for (; x < count; x++) {
                empList[x] = empList[x + 1];
            }
            count--;
        }
        return temp;
    }

    public int countHourlyEmp() {
        int ctr = 0;
        int x;
        for (x = 0; x < count; x++) {
            if (empList[x] instanceof hourlyEmployee) {
                ctr++;
            }
        }
        return ctr;
    }

    public int countPieceEmp() {
        int ctr = 0;
        int x;
        for (x = 0; x < count; x++) {
            if (empList[x] instanceof pieceWorkerEmployee) {
                ctr++;
            }
        }
        return ctr;
    }

    public int countCommissionEmp() {
        int ctr = 0;
        int x;
        for (x = 0; x < count; x++) {
            if (empList[x] instanceof commissionEmployee && !(empList[x] instanceof basePlusCommissionEmployee)) {
                ctr++;
            }
        }
        return ctr;
    }

    public int countBasePlusCommissionEmp() {
        int ctr = 0;
        int x;
        for (x = 0; x < count; x++) {
            if (empList[x] instanceof basePlusCommissionEmployee) {
                ctr++;
            }
        }
        return ctr;
    }

}