/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version5;
import java.time.*;

/**
 *
 * @author Hikari Cookies
 */
public class Employee {
    protected int empID;
    protected Name empName;
    protected LocalDate dateHired;
    protected LocalDate birthDate;

    public Employee(int empID, Name empName, LocalDate dateHired, LocalDate birthDate) {
        this.empID = empID;
        this.empName = empName;
        this.dateHired = dateHired;
        this.birthDate = birthDate;
    }

    public Employee(Name name, LocalDate dateHired, LocalDate birthDate) {
        this.empName = name;
        this.birthDate = birthDate;
        this.dateHired = dateHired;
    }
    
    public Employee(LocalDate dateHired, LocalDate birthDate) {
        this.dateHired = dateHired;
        this.birthDate = birthDate;
    }

    public Employee() {
        this.empName = new Name();
        this.dateHired = LocalDate.now();
        this.birthDate = LocalDate.now();
    }

    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public Name getEmpName() {
        return empName;
    }

    public void setEmpName(Name empName) {
        this.empName = empName;
    }

    public LocalDate getDateHired() {
        return dateHired;
    }

    public void setDateHired(LocalDate dateHired) {
        this.dateHired = dateHired;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }
    
    public String getDates(LocalDate date) {
        return String.format("%02d/%02d/%04d", date.getDayOfMonth(), date.getMonthValue(), date.getYear());
    }
    
    @Override
    public String toString() {
        return String.format("""
                             | Employee Name : %-30s 
                             | Date Hired: %-30s 
                             | Birthdate : %-30s 
                             """, empName.toString(),
                getDates(getDateHired()), getDates(getBirthDate()));
    }
    
    public void display() {
        
        System.out.println(this.toString());
    }
}
