/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version5;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Optional;

public class EmployeeRoster {
    LinkedList<Employee> empRoster;

    public EmployeeRoster() {
        empRoster = new LinkedList<>();
    }

    public EmployeeRoster(Employee[] empList) {
        empRoster.addAll(Arrays.asList(empList));
    }

    public void displayAllEmp() {
        System.out.printf("| %5s | %30s | %30s| %15s |\n", "ID", "Name", "Type", "Salary");
        for (Employee emp : empRoster) {
            String classType = emp.getClass().getSimpleName();
            double salary;

            switch (emp) {
                case hourlyEmployee hourlyEmp -> salary = hourlyEmp.computeSalary();
                case pieceWorkerEmployee pieceEmp -> salary = pieceEmp.computeSalary();
                case commissionEmployee commissionEmp -> salary = commissionEmp.computeSalary();
                default -> {
                    basePlusCommissionEmployee basePlusCommissionEmp = (basePlusCommissionEmployee) emp;
                    salary = basePlusCommissionEmp.computeSalary();
                }
            }

            System.out.printf("| %5d | %30s | %30s| PHP %11.2f |\n", emp.getEmpID(),
                    emp.getEmpName(),
                    classType,
                    salary);
        }
    }

    public void displayEmpOfType(String type) {
        Class<?> empType = switch (type.toUpperCase().charAt(0)) {
            case 'H' -> hourlyEmployee.class;
            case 'P' -> pieceWorkerEmployee.class;
            case 'C' -> commissionEmployee.class;
            case 'B' -> basePlusCommissionEmployee.class;
            default -> null;
        };

        for (Employee emp : empRoster) {
            if(empType != null) {
                if (empType.isInstance(emp)) {
                    emp.display();
                    System.out.println();
                }
            }
        }

    }

    public EmployeeRoster searchEmp(String key) {
        EmployeeRoster empList = new EmployeeRoster();

        empRoster.stream()
                .filter(emp -> emp.toString().contains(key))
                .forEach(empList::insertEmp);

        return empList;
    }

    public boolean insertEmp(Employee emp) {
        return empRoster.add(emp);
    }

    public boolean updateEmp(int empID, Employee emp) {
        Optional<Employee> Exist = empRoster.stream()
                .filter(e -> e.getEmpID() == empID)
                .findFirst();

        if (Exist.isPresent()) {
            empRoster.set(empRoster.indexOf(Exist.get()), emp);
            System.out.println("Successfully Updated Employee");
        }

        return Exist.isPresent();
    }

    public Employee removeEmployee(int ID) {
        return empRoster.removeIf(emp -> emp.getEmpID() == ID)
                ? empRoster.stream().filter(emp -> emp.getEmpID() == ID).findFirst().orElse(null)
                : null;
    }

    public int countHourlyEmp() {
        return (int) empRoster.stream()
                .filter(emp -> emp instanceof hourlyEmployee)
                .count();
    }

    public int countPieceEmp() {
        return (int) empRoster.stream()
                .filter(emp -> emp instanceof pieceWorkerEmployee)
                .count();
    }

    public int countCommissionEmp() {
        return (int) empRoster.stream()
                .filter(emp -> emp instanceof commissionEmployee && !(emp instanceof basePlusCommissionEmployee))
                .count();
    }

    public int countBasePlusCommissionEmp() {
        return (int) empRoster.stream()
                .filter(emp -> emp instanceof basePlusCommissionEmployee)
                .count();
    }
}