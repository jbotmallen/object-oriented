/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee.version5;
import employee.version4.*;
import java.time.LocalDate;

/**
 *
 * @author Hikari Cookies
 */
public class commissionEmployee extends Employee {
    protected double totalSales;

    public commissionEmployee() {
        super();
    }

    public commissionEmployee(Name empName, LocalDate dateHired, LocalDate birthDate) {
        super(empName, dateHired, birthDate);
    }

    public commissionEmployee(Name empName, LocalDate dateHired, LocalDate birthDate, double totalSales) {
        super(empName, dateHired, birthDate);
        this.totalSales = totalSales;
    }
    
    public double getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }
 
     public double computeSalary() {
        double retval;
        double sales = getTotalSales();
            
            if(sales < 50000) retval = sales * 0.05;
            else if(sales >= 50000 && sales < 100000) retval = sales * 0.20;
            else if(sales >= 100000 && sales < 500000) retval = sales * 0.30;
            else if(sales >= 500000) retval = sales * 0.50;
            else retval = 0;
            
        return retval;
    }
     
    public String getDetails() {
        return super.toString();
    }
    
    @Override
    public void display() {
        System.out.printf("%s| Salary : %5.0f\n", this.toString(), computeSalary());
    }

    @Override
    public String toString() {
        return String.format("%s\n %-40s \n%s\n%s| Total Sales : %5.0f\n", 
                "==============================================",
                "COMMISSION EMPLOYEE DETAILS",
                "==============================================",
                super.toString(), 
                getTotalSales()
        ); 
    }
}
